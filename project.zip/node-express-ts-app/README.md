# Node.js Express app CodeDeploy to AWS EC2 from GitHub Actions using CI/CD pipeline - starter template

---

Steps

1. Create a repo or clone this repo.
2. Set up AWS EC2.<br />
   2.1 Open a new EC2 instance and create a new Key pair. Copy to the home directory.<br />
   2.2 Go to the Security Groups. Create a new Security Group. Add ports `22 for SSH` and `3000 for Custom TCP` in Inbound Rules. They should be open for Anywhere/IPV4 (0.0.0.0).<br />
3. Create a role with S3 full access and Admin access.
4. if not present, create a new IAM user and grant it with the above role. Give it programmatic access so that it can access via AWS CLI.
5. Open AWS S3 and create a bucket with a name you want to save your files in. For eg., node-express-artifact.
6. Open a command prompt and configure AWS CLI for the IAM user. (give command - `aws configure` and enter access key, secret key and region).<br />
   To install AWS CLI - https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html
7.

## In the project terminal paste the following to upload the project zip to AWS S3 bucket.

---

```
zip -r project.zip . -x node_modules* dist* .git* && aws s3 cp project.zip s3://typescript-express-artifact-2/code-deploy-3/project.zip

aws deploy create-deployment
--application-name "node-express-app"
--deployment-config-name CodeDeployDefault.OneAtATime
--deployment-group-name ec2-app
--description "My demo deployment"
--s3-location bucket=typescript-express-artifact-2,bundleType=zip,key=code-deploy-3/project.zip
```
